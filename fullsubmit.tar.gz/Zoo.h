//Project Identifier: 3E33912F8BAA7542FC4A1585D2DB6FE0312725B9
#include <iostream>
#include <string>
#include <vector>
#include <tuple>
#include <limits> //numeric_limits<double>
#include <cstring>
#include <cstdint> //UINT32_MAX
#include <cmath> //sqrt, round
#include <unordered_set>
#include <algorithm> //sort, min
#include <getopt.h>

#ifndef ZOO_H
#define ZOO_H

enum class Mode {
    Unspecified,
    MST,
    FASTTSP,
    OPTTSP
};

enum class Category {
    Wild,
    Safe,
    WallCage
};

struct Vertex {
    int x;
    int y;
    //uint32_t id; //no need to store id. vector index is id.
    Category cat;
};

struct primsTable {
    bool kv;
    double dv;
    uint32_t pv;

    primsTable() : kv(false), dv(std::numeric_limits<double>::infinity()),
                    pv(UINT32_MAX) {} 
};

struct Edge {
    uint32_t u, v;
    double dist;
    Edge(uint32_t u, uint32_t v, double dist) : u(u), v(v), dist(dist) {}
};

inline bool compareEdges(const Edge& a, const Edge& b) {
    return a.dist < b.dist;
}

class Zoo {
    int _argc;
    char** _argv;
    bool _mode_flag;
    Mode _mode;
    uint32_t _num_vertices;
    uint32_t _arbitrary_root_id;
    double _mst_tot_dist; //sum of prim's table dists.
    double _fast_tot_dist;

    std::vector<Vertex> _vertices;
    std::vector<primsTable> _primsTable;
    std::vector<uint32_t> _fast_tsp_path;
public:
    Zoo(int argc, char** argv);

    double getDistance(Vertex v1, Vertex v2); //get euclid dist
    double getCost(uint32_t i, uint32_t k, uint32_t j);
    Category getCategory(int x, int y); //calculates & determines category
    void initPrimsTable(); //inits via root id
    void printMST();
    void primsLinear();
    void randInsTSP();
    void printFastTSP();
    //void christofidesAlg(); //run Christofide's Algorithm
    //std::unordered_set<uint32_t> getOddVertices(); //count # of odd degree vertices
    //std::vector<Edge> findMWPM(std::unordered_set<uint32_t> odd_vertices); //Minimum-Weight Perfect Matching (christofides step 2)
    
    void readInput(); //reads input redirection via cin. 
    void runSpecifiedMode();
    void runMST();
    void runFASTTSP();
    void runOPTTSP();
};

#endif //ZOO_H