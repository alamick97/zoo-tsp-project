//Project Identifier: 3E33912F8BAA7542FC4A1585D2DB6FE0312725B9

#include <iostream>
#include "Zoo.h"

int main (int argc, char** argv) {
    std::ios_base::sync_with_stdio(false); //Speeds up project's I/O

    Zoo zoo(argc, argv);
    zoo.readInput();
    //TODO: Implement part A.
    zoo.runMST();

    return 0;
}